#ifndef __MOTOR_H
#define __MOTOR_H

void Motor_Init(void);
void Motor_SetSpeed(int8_t Speed);
void PWM_Motor_Init(void);
void PWM_Motor_SetCompare1(uint16_t Compare);

#endif
